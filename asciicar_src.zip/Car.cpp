// asciicar/Car.cpp
// Contains the car physics.

// C++ includes
#include <algorithm>
#include <vector>

// C includes
#include <cstdint>

// project includes
#include "Car.hpp"
#include "utility.hpp"

/* Car constructor */
Car::Car(int start_x, int start_y): x{start_x}, y{start_y} {};

/**
 * Runs the car physics for a single tick.
 * (weird sort of cheaty "momentum" to allow pathfinding to work,
 * I was using actual momentum before with doubles but Djikstra
 * doesn't really work well with that)
 * 
 * @param right whether the right arrow key is pressed
 * @param left whether the left arrow key is pressed
 * @param down whether the down arrow key is pressed
 * @param up whether the up arrow key is pressed
 * @param map the map to check collision on
 */
void Car::tick(bool right, bool left, bool down, bool up, std::vector<std::vector<Cell>> map) {
    // x movement
    if (x_counter == 0) {
        // switch direction if needed
        if ((right && x_dir == -1) || (left && x_dir == 1)) {
            x_dir *= -1;
            x_speed = -1;
        }

        // change speed
        if ((right && x_dir == 1) || (left && x_dir == -1)) x_speed = std::min(x_speed + 1, 5);
        else if (right || left) x_speed = 0;
        else x_speed = std::max(x_speed - 1, 0);

        // move one cell in correct dir
        if (x_speed) x += x_dir;

        // check for collision
        if (map[y][x].type == WALL) {
            x -= x_dir;
            x_speed = 0;
        }

        // set counter
        if (x_speed > 0) x_counter = 5 - x_speed;
    } else
        --x_counter;

    // y movement (literally the exact same code again but with "y" instead of "x")
    //            (I'm such a great programmer wow)
    if (y_counter == 0) {
        // switch direction if needed
        if ((down && y_dir == -1) || (up && y_dir == 1)) {
            y_dir *= -1;
            y_speed = -1;
        }

        // change speed
        if ((down && y_dir == 1) || (up && y_dir == -1)) y_speed = std::min(y_speed + 1, 5);
        else if (down || up) y_speed = 0;
        else y_speed = std::max(y_speed - 1, 0);

        // move one cell in correct dir
        if (y_speed) y += y_dir;

        // check for collision
        if (map[y][x].type == WALL) {
            y -= y_dir;
            y_speed = 0;
        }

        // set counter
        if (y_speed > 0) y_counter = 5 - y_speed;
    } else
        --y_counter;
}