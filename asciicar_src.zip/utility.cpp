// asciicar/utility.cpp
// Contains utility functions.

// C++ includes
#include <string>

// C includes
#include <curses.h>

/* Terminates curses and SDL. */
void terminate() {
    curs_set(1);
    echo();
    keypad(stdscr, false);
    nocbreak();
    endwin();
}

/**
 * Takes a number and returns its sign.
 * 
 * @param n the number to get the sign of
 * @return the sign of the number
 */
int sign(double n) {
    if (n > 0) return 1;
    else if (n < 0) return -1;
    else return 0;
}

/**
 * Converts an amount of frames to seconds and returns the result as a string, truncated to 2 decimal places.
 * 
 * @param frame_count frames to convert
 * @param framerate frames per second
 * @return formatted string
 */
std::string frames_to_seconds_str(int frame_count, int framerate) {
    double seconds = (double) frame_count / (double) framerate;
    int seconds_hundredths = seconds / 0.01;
    return std::to_string(seconds_hundredths / 100) + "." + std::to_string(seconds_hundredths % 100);
}