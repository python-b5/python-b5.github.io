// asciicar/pathfind.hpp
// Contains pathfinding code.

// C++ includes
#include <utility>
#include <vector>

// C includes
#include <cstdint>

// project includes
#include "Car.hpp"
#include "utility.hpp"

#ifndef PATHFIND
    #define PATHFIND

    // djikstra node
    struct Node {
        // members
        Node *parent;
        int cost;
        uint8_t inputs;

        int car_x, car_y;
        int car_x_speed, car_y_speed;
        int car_x_dir, car_y_dir;
        int car_x_counter, car_y_counter;

        // methods
        Node(
            Node *parent_,
            int cost_,
            uint8_t inputs_,
            int car_x_, int car_y_,
            int car_x_speed_, int car_y_speed_,
            int car_x_dir_, int car_y_dir_,
            int car_x_counter_, int car_y_counter_
        );
    };

    // functions
    std::vector<uint8_t> pathfind(std::pair<int, int> start, std::pair<int, int> end, std::vector<std::vector<Cell>> map);
#endif