# map_compile.py
# by python-b5
#
# Compiles a plain-text map into a minified C++ file.

import os
import sys

if len(sys.argv) < 3:
    print("Missing argument(s)")
    os._exit(1)

try:
    with open(sys.argv[1]) as file:
        data = [list(line) for line in file.read().split("\n")]
except FileNotFoundError:
    print("Invalid file path")
    os._exit(1)

if os.path.exists(sys.argv[2]):
    print("Output file already exists")
    os._exit(1)

file = open(sys.argv[2], "w+")
file.write("std::vector<std::vector<Cell>>map={")

for y, line in enumerate(data):
    file.write("{")

    for x, char in enumerate(line):
        file.write(f"{{'{char}',{'WALL' if char == '#' else 'DECO'}}},")

    file.write("},")

file.write("};")
file.close()
