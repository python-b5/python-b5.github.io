# path_compile.py
# by python-b5
#
# Compiles a raw log file from the pathfinder into a minified C++ file.

import os
import sys

if len(sys.argv) < 3:
    print("Missing argument(s)")
    os._exit(1)

try:
    with open(sys.argv[1]) as file:
        data = [line.split(",")[:-1] for line in file.read().split("\n")]
        data.reverse()
except FileNotFoundError:
    print("Invalid file path")
    os._exit(1)

final = []

for line in data:
    final.append("|".join(key.upper() for key in line) if line else "0")

if os.path.exists(sys.argv[2]):
    print("Output file already exists")
    os._exit(1)

with open(sys.argv[2], "w+") as file:
    file.write(f"std::vector<uint8_t>inputs={{{','.join(final)}}};")
