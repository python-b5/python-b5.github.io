# asciicar
**A small racing game that runs in the terminal.**

---

### BUILD INSTRUCTIONS
- Requirements:
    - `MinGW` (`x64`)
    - `PDCurses`
- Change the paths in the makefile to be correct, then just run `make`.

### NOTES
- Requires a terminal size of at least `80x24` (as it would likely be unplayable smaller than that). The game's view will expand to fill any larger terminal.
- This is Windows-only because of the way key input is done (using `<Windows.h>`). The rest of it should work fine with `ncurses`, but you'd have to port the input logic to Mac/Linux in some way.
- `pathfind.cpp` and `pathfind.hpp` were originally written to be used in-game, but ended up being far too slow for that purpose. Because of this, they are not used in the final game, though they still work as part of the main project if included, and require `utility.hpp` and `Car.hpp` from the main project as well.
- `/tools` contains a couple Python scripts used in development.
    - `map_compile.py` compiles a map from a plain `.txt` file to a `.cpp` file for inclusion in the game.
    - `path_compile.py` compiles a raw log file from the pathfinder to a `.cpp` file for inclusion in the game.
- The uncompiled `map.txt` and `log.txt` files is provided for convenience.