// asciicar
// by python-b5
//
// A small racing game that runs in the terminal.

// C++ includes
#include <chrono>
#include <ratio>
#include <string>
#include <thread>
#include <unordered_map>
#include <utility>
#include <vector>

// C includes
#include <cmath>
#include <cstdint>
#include <cstdio>

#include <curses.h>
#include <Windows.h>  // Windows-only :/
                      // I couldn't find a good way to handle key input on Mac/Linux.
                      // If the key logic is ported this should work fine on other platforms.
                      // (getch only does one key at a time so couldn't be used)

// project includes
#include "Car.hpp"
#include "utility.hpp"

int main(int argc, char *argv[]) {
    // initialize curses
    initscr();
    cbreak();
    keypad(stdscr, true);
    curs_set(0);

    // initialize color
    start_color();
    init_pair(1, 8, 0);
    init_pair(2, COLOR_RED, 0);
    init_pair(3, COLOR_CYAN, 0);

    // get terminal size and center pos
    int rows, cols;
    getmaxyx(stdscr, rows, cols);

    int center_x = cols / 2;
    int center_y = rows / 2;

    // check if terminal is large enough
    if (rows < 24 || cols < 80) {
        terminate();
        printf("Terminal is too small (< 80x24!)");
        return 0;
    }

    // title screen
    mvaddstr(0, 0, "asciicar");
    mvaddstr(1, 0, "by python-b5");

    attron(COLOR_PAIR(1));
    mvaddstr(3, 0, "(any key to start)");
    attroff(COLOR_PAIR(1));

    getch();

    // include map and pre-calculated ai path
    #include "map.cpp"
    #include "path.cpp"

    // create cars
    Car car(18, 2);
    Car ai_car(18, 2);

    // get input ui pos
    int key_ui_top = rows - 2;

    // framerate variables
    // framerate code adapted from https://stackoverflow.com/questions/59165392/c-how-to-make-precise-frame-rate-limit
    const int framerate = 60;
    std::chrono::duration<double, std::ratio<1, framerate>> frame_time{1};
    std::chrono::time_point<std::chrono::high_resolution_clock, decltype(frame_time)> target_time = std::chrono::high_resolution_clock::now();

    size_t frame_count = 0;

    // game loop
    bool started = false;
    bool done = false;
    while (!done) {
        // handle input
        if ((GetAsyncKeyState(VK_CONTROL) & 0x8000) && (GetAsyncKeyState('C') & 0x8000)) {
            terminate();
            return 0;
        }

        const bool right = GetAsyncKeyState(VK_RIGHT) & 0x8000;
        const bool left = GetAsyncKeyState(VK_LEFT) & 0x8000;
        const bool down = GetAsyncKeyState(VK_DOWN) & 0x8000;
        const bool up = GetAsyncKeyState(VK_UP) & 0x8000;

        if (!started && (right || left || down || up)) started = true;

        uint8_t keys;

        if (started && frame_count < inputs.size())
            keys = inputs[frame_count];
        else
            keys = 0;

        // run car physics
        car.tick(right, left, down, up, map);
        ai_car.tick(keys & RIGHT, keys & LEFT, keys & DOWN, keys & UP, map);

        // draw map
        erase();

        int map_y = 0;

        for (const std::vector<Cell> &row : map) {
            int map_x = 0;

            for (const Cell &cell : row) {
                attron(COLOR_PAIR(1));
                mvaddch(center_y + (map_y - car.y), center_x + (map_x - car.x), cell.ch);
                attroff(COLOR_PAIR(1));

                ++map_x;
            }

            ++map_y;
        }

        // draw cars
        attron(COLOR_PAIR(2));
        mvaddch(center_y + (ai_car.y - car.y), center_x + (ai_car.x - car.x), '@');
        attroff(COLOR_PAIR(2));

        attron(COLOR_PAIR(3));
        mvaddch(center_y, center_x, '@');
        attroff(COLOR_PAIR(3));

        // draw ui
        int time_sec = frame_count / framerate;
        mvaddstr(0, 0, ("Time: " + std::to_string(time_sec) + " seconds (" + std::to_string(frame_count) + " frames)").data());

        attron(COLOR_PAIR(1));
        mvaddch(key_ui_top, 1, '^');
        mvaddstr(key_ui_top + 1, 0, "<v>");
        attroff(COLOR_PAIR(1));

        if (right) mvaddch(key_ui_top + 1, 2, '>');
        if (left) mvaddch(key_ui_top + 1, 0, '<');
        if (down) mvaddch(key_ui_top + 1, 1, 'v');
        if (up) mvaddch(key_ui_top, 1, '^');

        refresh();

        // maintain fps
        target_time += frame_time;
        std::this_thread::sleep_until(target_time);

        // check if reached end
        if (car.x == 21 && car.y == 44) {
            // hide pressed keys
            attron(COLOR_PAIR(1));
            mvaddch(key_ui_top, 1, '^');
            mvaddstr(key_ui_top + 1, 0, "<v>");
            attroff(COLOR_PAIR(1));
            refresh();

            // wait one second
            target_time += frame_time * framerate;
            std::this_thread::sleep_until(target_time);

            // end loop
            break;
        } else if (started) ++frame_count;
    }

    // show end screen
    erase();

    int time_sec = frame_count / framerate;
    mvaddstr(0, 0, ("Time: " + std::to_string(time_sec) + " seconds (" + std::to_string(frame_count) + " frames)").data());

    if (frame_count < inputs.size())
        mvaddstr(1, 0, "You won!");
    else if (frame_count == inputs.size())
        mvaddstr(1, 0, "You tied!");
    else
        mvaddstr(1, 0, "You lost...");

    attron(COLOR_PAIR(1));
    mvaddstr(3, 0, "(any key to quit)");
    attroff(COLOR_PAIR(1));

    flushinp();
    getch();

    // terminate curses
    terminate();
}