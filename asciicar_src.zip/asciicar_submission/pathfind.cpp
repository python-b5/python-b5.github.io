// asciicar/pathfind.cpp
// Contains pathfinding code.
//
// Ported + adapted from platformer-ai/pathfind.py.

// C++ includes
#include <algorithm>
#include <fstream>
#include <utility>
#include <vector>
#include <queue>

// C includes
#include <cmath>
#include <cstdint>

// project includes
#include "Car.hpp"
#include "pathfind.hpp"
#include "utility.hpp"

struct NodeCompare {
    /**
     * Checks if a given node is more expensive than another.
     * 
     * @param lhs node to check
     * @param rhs node to compare against
     * @return whether the first node is more expensive
     */
    bool operator()(Node *lhs, Node *rhs) {
        return lhs->cost > rhs->cost;
    }
};

/* Node constructor */
Node::Node(
    Node *parent_,
    int cost_,
    uint8_t inputs_,
    int car_x_, int car_y_,
    int car_x_speed_, int car_y_speed_,
    int car_x_dir_, int car_y_dir_,
    int car_x_counter_, int car_y_counter_
):
    parent(parent_),
    cost(cost_),
    inputs(inputs_),
    car_x(car_x_), car_y(car_y_),
    car_x_speed(car_x_speed_), car_y_speed(car_y_speed_),
    car_x_dir(car_x_dir_), car_y_dir(car_y_dir_),
    car_x_counter(car_x_counter_), car_y_counter(car_y_counter_)
{}

/**
 * Finds the shortest path between two points using Djikstra's algorithm and car physics.
 * Writes to a log file as well as returning the result.
 * 
 * @param start the starting position
 * @param end the position to pathfind to
 * @param map the map to check collision on
 * @return a vector of inputs for each frame
 */
std::vector<uint8_t> pathfind(std::pair<int, int> start, std::pair<int, int> end, std::vector<std::vector<Cell>> map) {
    // create starting node
    Node *start_node = new Node(NULL, 0, 0, start.first, start.second, 0, 0, 1, 1, 0, 0);

    // all nodes created in total (for freeing afterwards)
    std::vector<Node *> all_nodes;

    // heap of open nodes
    std::priority_queue<Node *, std::vector<Node *>, NodeCompare> open;
    open.push(start_node);

    // traveled positions
    std::vector<std::vector<int>> traveled;

    // mainloop
    while (true) {
        // get current node if possible
        Node *current;

        if (open.empty()) {
            // delete nodes to free memory
            for (Node *node : all_nodes) delete node;

            // return nothing as level is impossible
            return {};
        } else {
            current = open.top();
            open.pop();
        }

        // check if end was reached
        if (current->car_x == end.first && current->car_y == end.second) {
            // open file
            std::ofstream file;
            file.open("log.txt");

            // create path
            std::vector<uint8_t> path;

            // walk backwards through nodes until start
            while (current->parent != NULL) {
                // write to file
                if (current->inputs & RIGHT) file << "right,";
                if (current->inputs & LEFT) file << "left,";
                if (current->inputs & DOWN) file << "down,";
                if (current->inputs & UP) file << "up,";
                file << "\n";

                // insert inputs at start of path and find next node
                path.insert(path.begin(), current->inputs);
                current = current->parent;
            }

            // delete nodes to free memory
            for (Node *node : all_nodes) delete node;

            file.close();
            return path;
        }

        // loop through key combinations
        for (uint8_t inputs = 0; inputs <= 10; ++inputs) {
            // hardcoded invalid inputs (a.k.a. ones with left+right or up+down)
            // (only two of them are here since the others are covered by stopping the loop at 10)
            if (inputs == 3 || inputs == 7) continue;

            // copy car and run tick
            Car car(current->car_x, current->car_y);
            car.x_speed = current->car_x_speed;
            car.y_speed = current->car_y_speed;
            car.x_dir = current->car_x_dir;
            car.y_dir = current->car_y_dir;
            car.x_counter = current->car_x_counter;
            car.y_counter = current->car_y_counter;

            car.tick(inputs & RIGHT, inputs & LEFT, inputs & DOWN, inputs & UP, map);

            // check if new pos is valid
            if (map[car.y][car.x].type != WALL) {
                // collect car values
                std::vector<int> car_values = {car.x, car.y, car.x_speed, car.y_speed, car.x_dir, car.y_dir, car.x_counter, car.y_counter};

                // check if position isn't traveled already
                if (std::find(traveled.begin(), traveled.end(), car_values) == traveled.end()) {
                    // create child node
                    Node *child = new Node(
                        current,
                        current->cost + 1,
                        inputs, car.x, car.y, car.x_speed, car.y_speed, car.x_dir, car.y_dir, car.x_counter, car.y_counter
                    );

                    // flag child node as open and position as traveled
                    all_nodes.push_back(child);
                    open.push(child);
                    traveled.push_back(car_values);
                }
            }
        }
    }
}