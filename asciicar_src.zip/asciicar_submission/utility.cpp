// asciicar/utility.cpp
// Contains utility functions.

// C includes
#include <curses.h>

/* Terminates curses and SDL. */
void terminate() {
    curs_set(1);
    keypad(stdscr, false);
    nocbreak();
    endwin();
}

/**
 * Takes a number and returns its sign.
 * 
 * @param n the number to get the sign of
 * @return the sign of the number
 */
int sign(double n) {
    if (n > 0) return 1;
    else if (n < 0) return -1;
    else return 0;
}