// asciicar/Car.hpp
// Contains the car physics.

// C++ includes
#include <vector>

// C includes
#include <cstdint>

// project includes
#include "utility.hpp"

#ifndef CAR
    #define CAR

    class Car {
        public:
            // public members
            int x;
            int y;

            uint8_t inputs;

            int x_speed = 0;
            int y_speed = 0;

            int x_dir = 1;
            int y_dir = 1;

            int x_counter = 0;
            int y_counter = 0;

            // public methods
            Car(int start_x, int start_y);
            void tick(bool right, bool left, bool down, bool up, std::vector<std::vector<Cell>>);
    };
#endif