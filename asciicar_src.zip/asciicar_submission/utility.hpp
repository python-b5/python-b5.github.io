// asciicar/utility.hpp
// Contains miscellaneous utility functions/values.

// C includes
#include <cstdint>

#ifndef UTILITY
    #define UTILITY

    // keys
    const uint8_t RIGHT = 1;
    const uint8_t LEFT = 1 << 1;
    const uint8_t DOWN = 1 << 2;
    const uint8_t UP = 1 << 3;

    // cell types
    enum TYPE {
        DECO,  // no collision
        WALL,  // collision
        SLOW   // slows the car down
    };

    // map cell
    struct Cell {
        char ch;
        TYPE type;
    };

    // functions
    void terminate();
    int sign(double n);
#endif