# platformer-ai/engine.py
# by python-b5
#
# Contains game engine code.


# Imports
from keys import Key
from logic import collision


class Player:
    """A player in the game (human/bot)."""
    def __init__(self, level, x, y):
        # Level to check collisions in
        self.level = level

        # Position variables
        self.x = x
        self.y = y

        # Jump variables
        self.jump_height = 3
        self.hang_time = 1
    
        # Airtime variables
        self.up = False
        self.up_count = 0

    def tick(self, keys):
        """Runs a game tick for this player."""
        # Check if player is on the ground
        ground = False
        
        if collision(self.level, self.x, self.y + 1):
            ground = True
            
            # Start jump if jump key pressed
            if Key.JUMP in keys:
                self.up = True

        # Horizontal movement
        horizontal = False
        
        if Key.RIGHT in keys and not collision(self.level, self.x + 1, self.y):
            self.x += 1
            horizontal = True

        if Key.LEFT in keys and not collision(self.level, self.x - 1, self.y):
            self.x -= 1
            horizontal = True

        # Jumping
        if self.up:
            # Increase airtime counter
            self.up_count += 1

            # Move player upwards if possible
            if self.up_count < self.jump_height:
                if not collision(self.level, self.x, self.y - 1):
                    self.y -= 1
                else:
                    # Otherwise, end the jump immediately
                    self.up_count = self.jump_height + self.hang_time

            # End jump
            if self.up_count == self.jump_height + self.hang_time:
                self.up = False
                self.up_count = 0
        else:
            # Gravity (only if player didn't just walk off a ledge)
            if (
                not collision(self.level, self.x, self.y + 1)
                and not ground
            ):
                self.y += 1

        # Horizontal movement (for diagonal)
        if not horizontal:
            if (
                Key.RIGHT in keys
                and not collision(self.level, self.x + 1, self.y)
            ):
                self.x += 1
    
            if (
                Key.LEFT in keys
                and not collision(self.level, self.x - 1, self.y)
            ):
                self.x -= 1
