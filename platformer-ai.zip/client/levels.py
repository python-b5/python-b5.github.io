# platformer-ai/levels.py
# by python-b5
#
# Contains level loading utilities.


def load(level):
    """Loads a level as a list of lines, returning None on error."""
    # Split level into lines
    level = [list(line) for line in level.split("\n")]

    # Initialize start and end positions
    start = None
    end = None

    # Initialize handicaps list
    handicaps = []

    # Loop through level
    for y, row in enumerate(level):
        for x, char in enumerate(row):
            # Check if char is the start or end position
            if char == "S":
                start = (x, y)
            elif char == "E":
                end = (x, y)
            elif char == "H":
                handicaps.append((x, y))  
    
    # Check if start and end were found
    if start and end:
        # Remove start position from level
        level[start[1]][start[0]] = " "

        # Remove handicap positions from level
        for handicap in handicaps:
            level[handicap[1]][handicap[0]] = " "

        # Return level data
        return level, start, end, handicaps
    else:
        return None
