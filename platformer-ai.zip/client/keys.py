# platformer-ai/keys.py
# by python-b5
#
# Contains keyboard input utilities.


# Imports
import keyboard


class Key:
    """Stores key constants."""
    RIGHT = "right"
    LEFT = "left"
    
    JUMP = "z"


# List of possible keys
keys = [Key.RIGHT, Key.LEFT, Key.JUMP]


def pressed_keys():
    """Returns all currently pressed keys (out of the possible ones)."""
    return [key for key in keys if keyboard.is_pressed(key)]
