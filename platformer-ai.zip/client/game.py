# platformer-ai/game.py
# by python-b5
#
# Contains level playing utilities.


# Imports
import copy
import curses
import fpstimer
import time

from engine import Player
from keys import pressed_keys
from logic import collision
from pathfind import pathfind
from wrapper import getch


def play(window, level, start, end, handicaps, ai_wait=None):
    """Plays a level (with or without AI)."""
    # Create player
    player = Player(level, *start)

    # Set framerate
    framerate = 10

    # Frame count
    frame = 0

    # Create timer
    timer = fpstimer.FPSTimer(framerate)

    # Whether the level has started
    started = False

    # Main game loop
    done = False
    while not done:
        # Check if started
        if started:
            # Get old player position
            old_x = player.x
            old_y = player.y

            # Run player logic
            player.tick(pressed_keys())

            # Check if path is active
            if ai_wait != None and path_progress < len(path) - 1:
                try:
                    # Get next node in path
                    next_node = path[round(path_progress) + 1]

                    # Check if about to jump
                    if (
                        next_node[2] and not (
                            current_node[2] and current_node[3] < current_node[4]
                        )
                    ):
                        if countdown == 0:
                            countdown = ai_wait
                        else:
                            countdown -= 1
                except IndexError:
                    pass

                # Advance path
                if countdown == 0:
                    path_progress += 1
                
                # Get old node in path
                old_node = current_node

                # Get current node in path
                current_node = path[round(path_progress)]

        # Check if player is colliding with danger
        if collision(level, player.x, player.y, char="X"):
            # Set message
            message = "You died!"

            # Flag as dead
            won = None

            # End loop
            break
        
        # Check if player has completed the level
        if collision(level, player.x, player.y, char="E"):
            # Set message
            message = "You won!"

            # Flag as won
            won = True

            # End loop
            break

        # Check if AI has completed the level
        if (
            started
            and ai_wait != None
            and collision(level, current_node[0], current_node[1], char="E")
        ):
            # Set message
            message = "You lost!"

            # Flag as lost
            won = False

            # End loop
            break

        # Clear window
        window.clear()

        # Draw level
        for y, line in enumerate(level):
            for x, char in enumerate(line):
                window.addstr(
                    y,
                    x,
                    char,
                    curses.color_pair({" ": 0, "#": 1, "X": 3, "E": 4}[char])
                )

        # Draw AI player if path is active
        if started and ai_wait != None and path_progress < len(path) - 1:
            window.addch(
                current_node[1],
                current_node[0],
                "@",
                curses.color_pair(1)
            )

        # Draw player
        window.addch(player.y, player.x, "@", curses.color_pair(2))

        # Check if not started
        if not started:
            if ai_wait != None:
                # Draw message
                window.addstr(len(level) + 1, 0, "Solving level...")

                # Refresh window
                window.refresh()

                # AI version of level
                ai_level = copy.deepcopy(level)

                # Apply handicap
                if handicaps:
                    for handicap in handicaps:
                        ai_level[handicap[1]][handicap[0]] = "#"
                
                # Generate path
                path = pathfind(ai_level, start, end)

                # Current node
                current_node = path[0]

                # Progress through path
                path_progress = 0

                # Jump countdown
                countdown = 0

            # Loop 3 times, counting downwards
            for second in range(3, 0, -1):
                # Clear line
                window.move(len(level) + 1, 0)
                window.clrtoeol()

                # Draw second
                window.addstr(len(level) + 1, 0, f"{second}...")

                # Refresh window
                window.refresh()

                # Wait one second
                time.sleep(1)

            # Flag as started
            started = True
        else:
            # Refresh window
            window.refresh()

            # Wait for frame to finish
            timer.sleep()

        # Increase frame count
        frame += 1
    
    # Draw space over victorious/dead player
    if won != False:
        window.addch(old_y, old_x, " ")
    else:
        window.addch(old_node[1], old_node[0], " ")
    
    # Check if tied
    if ai_wait != None and won and (player.x, player.y) == current_node[:2]:
        # Change message
        message = "You tied!"
    
    # Draw message
    window.addstr(len(level) + 1, 0, message)

    # Draw time
    if won:
        window.addstr(len(level) + 2, 0, f"Took {frame} frames.")
        offset = 2
    else:
        offset = 0
    
    # Draw key prompt
    window.addstr(
        len(level) + 2 + offset,
        0,
        "(any key to continue)",
        curses.color_pair(1)
    )

    # Refresh window
    window.refresh()

    # Wait for keys to be unpressed
    while pressed_keys():
        pass

    # Wait for key
    getch(window)

    # Return whether the player won
    return won


def play_lambda(*args, **kwargs):
    """Returns a lambda function that plays a level."""
    return lambda: play(*args, **kwargs)
