# platformer-ai/database.py
# by python-b5
#
# Contains database access utilities.
#
# If the server returns an error, these functions will raise custom
# exceptions with the given text.


# Imports
import json
import requests
import socket
import urllib.parse


# Database domain and URL
DATABASE_DOMAIN = "platformer-ai.python-b5.com"
DATABASE_URL = f"http://{DATABASE_DOMAIN}/api/"


# Switch to localhost if server is hosted on this PC
if (
    socket.gethostbyname(DATABASE_DOMAIN)
    == requests.get("https://api.ipify.org/").text
):
    DATABASE_URL = "http://127.0.0.1/api/"


class DatabaseError(Exception):
    """A custom exception type for the database."""
    pass


def get_levels():
    """Returns all levels in the database."""
    return json.loads(
        requests.get(urllib.parse.urljoin(DATABASE_URL, "levels/")).text
    )


def user_levels(username):
    """Returns a specific user's levels."""
    # Attempt to get levels
    response = requests.get(
        urllib.parse.urljoin(DATABASE_URL, f"levels/{username}/")
    )

    # Check response code
    if response.status_code == 200:
        return json.loads(response.text)
    else:
        raise DatabaseError(response.text)


def upload_level(auth, name, description, level):
    """Uploads a level to the database."""
    # Attempt to upload level
    response = requests.post(
        urllib.parse.urljoin(DATABASE_URL, f"levels/"),
        data={
            "username": auth[0],
            "password": auth[1],
            "name": name,
            "description": description,
            "level": level
        }
    )

    # Check response code
    if response.status_code != 201:
        raise DatabaseError(response.text)


def delete_level(auth, name):
    """Deletes a level from the database."""
    # Attempt to delete level
    response = requests.delete(
        urllib.parse.urljoin(DATABASE_URL, f"levels/"),
        data={"username": auth[0], "password": auth[1], "name": name}
    )

    # Check response code
    if response.status_code != 200:
        raise DatabaseError(response.text)


def create_user(name, password):
    """Adds a user to the database."""
    # Attempt to create user
    response = requests.post(
        urllib.parse.urljoin(DATABASE_URL, f"users/"),
        data={"name": name, "password": password}
    )

    # Check response code
    if response.status_code != 201:
        raise DatabaseError(response.text)
