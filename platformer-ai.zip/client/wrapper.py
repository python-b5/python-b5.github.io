# platformer-ai/wrapper.py
# by python-b5
#
# Contains curses wrapper code and drawing utilities.
#
# Adapted from terminal-minesweeper:
# https://www.pyth.link/minesweeper


# Imports
import curses
import traceback


def terminate():
    """
    Terminates curses, returning the terminal to its usual state, and
    stops the key listener thread.
    """
    curses.nocbreak()
    curses.curs_set(1)
    curses.echo()
    curses.endwin()


def getch(window):
    """A wrapper around window.getch() that flushes the input buffer."""
    # Flush input
    curses.flushinp()

    # Get key
    key = window.getch()

    # Flush input (again)
    curses.flushinp()

    # Return key
    return key


def box(window, x, y, width, height, attr=0):
    """Draws a box of a given size."""
    for line in range(height):
        if line == 0:  # Top of box
            window.addstr(line, x, "┌" + "─" * (width - 2) + "┐", attr)
        elif line == height - 1:  # Bottom of box
            window.addstr(line, x, "└" + "─" * (width - 2) + "┘", attr)
        else:  # Middle of box
            window.addch(line, x, "│", attr)
            window.addch(line, x + width - 1, "│", attr)


def wrapper(function):  
    # Initialize window
    window = curses.initscr()
    window.keypad(True)

    # Curses options
    curses.cbreak()
    curses.curs_set(0)
    curses.noecho()
    
    # Initialize color pairs
    curses.start_color()

    curses.init_pair(1, 8, curses.COLOR_BLACK)
    curses.init_pair(2, curses.COLOR_BLUE, curses.COLOR_BLACK)
    curses.init_pair(3, curses.COLOR_RED, curses.COLOR_BLACK)
    curses.init_pair(4, curses.COLOR_GREEN, curses.COLOR_BLACK)

    # Run function (terminating on exit/exception)
    try:
        function(window)

        window.keypad(False)
        terminate()
    except:
        terminate()
        traceback.print_exc()
