# platformer-ai/pathfind.py
# by python-b5
#
# Contains the pathfinding code for the game.
#
# Adapted from part of one of my Advent of Code solutions:
# https://github.com/python-b5/advent-of-code-2021/blob/main/day_15_part_1.py


# Imports
import heapq

from copy import deepcopy
from engine import Player
from keys import Key
from logic import collision


class Node:
    """Represents a single node."""
    def __init__(self, parent, player, cost):
        self.parent = parent
        self.player = player
        self.cost = cost

    def __hash__(self):
        return hash((
            self.player.x,
            self.player.y,
            self.player.up,
            self.player.up_count
        ))

    def __eq__(self, other):
        # Only check the position of the player
        return (
            (self.player.x, self.player.y) == (other.player.x, other.player.y)
        )

    def __lt__(self, other):
        return self.cost < other.cost


def pathfind(level, start, end):
    """
    Solves a given level using Djikstra's algorithm and platformer
    physics.
    """
    # Create start and end nodes
    start_node = Node(None, Player(level, *start), 0)
    end_node = Node(None, Player(level, *end), 0)

    # Create lists
    open_ = [start_node]
    closed = set()
    traveled = set()

    # Heapify open list
    heapq.heapify(open_)

    while True:
        # Get current node
        try:
            current_node = heapq.heappop(open_)
        except IndexError:
            # Return None as level is impossible
            return None

        # Check if the end was reached
        if current_node == end_node:
            # Initialize path
            path = [(
                current_node.player.x,
                current_node.player.y,
                current_node.player.up,
                current_node.player.up_count,
                current_node.player.jump_height
            )]

            # Backtrack until the start is reached
            while current_node != start_node:
                current_node = current_node.parent
                path.append((
                    current_node.player.x,
                    current_node.player.y,
                    current_node.player.up,
                    current_node.player.up_count,
                    current_node.player.jump_height
                ))

            # Reverse and return path
            return list(reversed(path))
        else:
            # Otherwise, add the current node to the closed set
            closed.add(current_node)
        
        for combination in [
            (),
            (Key.LEFT,),
            (Key.RIGHT,),
            (Key.JUMP,),
            (Key.LEFT, Key.JUMP),
            (Key.RIGHT, Key.JUMP)
        ]:
            # Copy player and run tick
            player = deepcopy(current_node.player)
            player.tick(keys=combination)

            # Check if player position is valid
            if not collision(level, player.x, player.y, char="X"):
                # Create child node
                child = Node(
                    current_node,
                    player,
                    current_node.cost + 1 + len(combination)
                )

                # Check if child node has already been traveled or closed
                if child not in traveled and child not in closed:
                    # Mark child node as open and traveled
                    heapq.heappush(open_, child)
                    traveled.add(child)
