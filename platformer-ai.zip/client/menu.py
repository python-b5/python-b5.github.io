# platformer-ai/menu.py
# by python-b5
#
# Contains menu and user interface functions.


# Imports
import curses

from wrapper import getch


def menu(window, prefix, options, allow_back=False):
    """
    Creates a multiple choice menu, allowing for multiple menus to be nested
    inside each other.
    """
    # Cursor position
    pos = 0

    # Length of prefix (to offset menu)
    prefix_length = len(prefix.split("\n"))

    # Prompt with valid keys
    key_prompt = (
        "(arrows to select, Z to confirm"
        + (")", ", X to go back)")[allow_back]
    )

    # Menu loop
    while True:
        # Display menu
        window.clear()

        window.addstr(0, 0, prefix, curses.A_BOLD)

        for i, option in enumerate(options):
            if isinstance(option, tuple):
                window.addstr(1 + prefix_length + i, 2, option[0])
            else:
                window.addstr(1 + prefix_length + i, 2, option)

        window.addch(1 + prefix_length + pos, 0, ">", curses.A_BOLD)

        window.addstr(
            2 + prefix_length + len(options),
            0,
            key_prompt,
            curses.color_pair(1)
        )

        # Get key
        key = getch(window)

        # Check key
        if key == curses.KEY_DOWN and pos < len(options) - 1:
            pos += 1
        elif key == curses.KEY_UP and pos > 0:
            pos -= 1
        elif key == ord("z"):
            # Check if a function was provided
            if isinstance(options[pos], tuple) and len(options[pos]) > 1:
                # Check if function is a submenu
                if (
                    isinstance(options[pos][1], tuple)
                    and options[pos][1][0] == "submenu"
                ):
                    # Run submenu
                    options[pos][1][1](window)
                else:
                    # Run function
                    options[pos][1]()
            else:
                # Otherwise, exit menu
                return
        elif key == ord("x") and allow_back:
            return
    
    return pos


def submenu(prefix, options):
    """Generates a lambda function that runs a submenu."""
    return (
        "submenu",
        lambda window: menu(window, prefix, options, allow_back=True)
    )
