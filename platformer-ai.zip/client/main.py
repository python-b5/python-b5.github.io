# platformer-ai
# by python-b5
#
# An ASCII platformer with an AI to race against.
# This is my unit 2 project for ICS3U.


# Imports
from database import get_levels
from game import play_lambda
from levels import load
from menu import menu, submenu
from wrapper import wrapper


def level_list(window):
    menu(
        window,
        "Levels:",
        [
            (
                f"{level['name']} (by {level['author']})",
                submenu(
                    f"{level['name']}\nby {level['author']}"
                    f"\n\n{level['description']}",
                    [
                        (
                            "Solo",
                            play_lambda(
                                window,
                                *(level_loaded := load(level["level"]))
                            )
                        ),
                        (
                            "Race (easy)",
                            play_lambda(window, *level_loaded, ai_wait=4)
                        ),
                        (
                            "Race (hard)",
                            play_lambda(
                                window,
                                *level_loaded[:-1],
                                None,
                                ai_wait=3
                            )
                        ),
                        (
                            "Race (impossible)",
                            play_lambda(
                                window,
                                *level_loaded[:-1],
                                None,
                                ai_wait=0
                            )
                        )
                    ]
                )
            ) for level in get_levels()
        ],
        allow_back=True
    )


def main(window):
    """Runs the main game."""
    menu(
        window,
        "platformer-ai\nby python-b5",
        [
            ("Play", lambda: level_list(window)),
            "Quit"
        ]
    )


# Run game
if __name__ == "__main__":
    wrapper(main)
