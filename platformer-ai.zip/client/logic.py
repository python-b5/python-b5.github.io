# platformer-ai/logic.py
# by python-b5
#
# Contains logic/math utilities.


def sign(n):
    """Returns the sign of a number."""
    if n > 0:
        return 1
    elif n < 0:
        return -1
    else:
        return 0


def collision(level, x, y, char="#"):
    """Checks if a position exists and is occupied in a given level."""
    try:
        return level[y][x] == char
    except IndexError:
        return True
