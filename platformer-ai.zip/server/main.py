# platformer-ai/server
# by python-b5
#
# A level sharing server for platformer-ai.
#
# This server is very inefficient, not scalable, and possibly insecure.
# It's designed to work just for the purposes of this small game, and
# shouldn't be seen as best practice in any way.
#
# This does not run over HTTPS right now, as I haven't gotten a
# certificate for it. I tried to make it at least somewhat secure, but
# definitely don't use any passwords on this that you've used anywhere
# else, just to be safe.


# Imports
import argon2
import flask
import json
import os
import waitress


# Working directory
WORKING_DIR = os.path.dirname(__file__)


# Database path
DATABASE_PATH = os.path.join(WORKING_DIR, "database.json")


# Initialize server
server = flask.Flask(__name__)


# Initialize password hasher
hasher = argon2.PasswordHasher()


def save():
    """Saves the database to a file."""
    with open(DATABASE_PATH, "w+") as file:
        json.dump({"users": users}, file)


def verify(username, password):
    """
    Verifies if user credentials are valid, and returns the user if they
    are.
    """
    # Get user
    try:
        user = next(user for user in users if user["name"] == username)
    except StopIteration:
        user = None

    # Check if user was found
    if user:
        # Check if password is valid
        if hasher.verify(user["password"], password):
            # Rehash password if needed
            if hasher.check_needs_rehash(user["password"]):
                user["password"] = hasher.hash(password)

            return user
        else:
            return False
    else:
        return None


@server.route("/", methods=["GET"])
def landing_page():
    """Provides basic information about the server."""
    return """<h1>platformer-ai level server</h1>
<p>This server stores user and level data for platformer-ai.</p>
<p>The API can be accessed at <code>/api/</code>.</p>
"""


@server.route("/api/levels/", methods=["GET"])
def get_levels():
    """Returns all levels in the database."""
    return (
        json.dumps([
            {"author": user["name"], **level}
            for user in users for level in user["levels"]
        ]),
        200
    )


@server.route("/api/levels/<username>/", methods=["GET"])
def user_levels(username):
    """Returns a specific user's levels."""
    # Get user
    try:
        user = next(user for user in users if user["name"] == username)
    except StopIteration:
        user = None

    # Check if user was found
    if user:
        return json.dumps(user["levels"]), 200
    else:
        return "User does not exist", 400


@server.route("/api/levels/", methods=["POST"])
def upload_level():
    """Uploads a level to the database."""
    # Get user
    user = verify(
        flask.request.values.get("username"),
        flask.request.values.get("password")
    )

    # Check if user was found and verified
    if user:
        # Get level data
        name = flask.request.values.get("name")
        description = flask.request.values.get("description")
        level = flask.request.values.get("level")

        # Check if data is valid
        if all(isinstance(data, str) for data in (name, description, level)):
            # Check if name is taken
            if not any(level["name"] == name for level in user["levels"]):
                # Upload level (TODO: verify that the level is possible)
                user["levels"].append({
                    "name": name,
                    "description": description,
                    "level": level
                })

                # Save database
                save()

                return "Level uploaded", 201
            else:
                return "Name taken", 400
        else:
            return "Invalid data", 400
    else:
        return "Invalid credentials", 401


@server.route("/api/levels/", methods=["DELETE"])
def delete_level():
    """Deletes a level from the database."""
    # Get user
    user = verify(
        flask.request.values.get("username"),
        flask.request.values.get("password")
    )

    # Check if user was found and verified
    if user:
        # Get level name
        name = flask.request.values.get("name")

        # Check if name is valid
        if isinstance(name, str):
            # Save current state of levels list
            old_levels = user["levels"]

            # Delete level
            user["levels"] = [
                level for level in user["levels"]
                if level["name"] != flask.request.values.get("name")
            ]

            # Check if level was found
            if user["levels"] != old_levels:
                # Save database
                save()

                return "Level deleted", 200
            else:
                return "Level does not exist", 400
        else:
            return "Invalid name", 400
    else:
        return "Invalid credentials", 401


@server.route("/api/users/", methods=["POST"])
def create_user():
    """Adds a user to the database."""
    # Get user data
    name = flask.request.values.get("name")
    password = flask.request.values.get("password")

    # Check if data is valid
    if all(isinstance(data, str) for data in (name, password)):
        # Check if name is taken
        if not any(user["name"] == name for user in users):
            # Create user
            users.append({
                "name": name,
                "password": hasher.hash(password),
                "levels": []
            })

            # Save database
            save()

            return "User created", 201
        else:
            return "Name taken", 400
    else:
        return "Invalid data", 400


# Run script
if __name__ == "__main__":
    try:
        # Load database
        with open(DATABASE_PATH) as file:
            users = json.load(file)["users"]
    except (FileNotFoundError, json.JSONDecodeError):
        # Create new database
        users = []

    # Run server
    server.run("0.0.0.0", port=80)#waitress.serve(server, port=80)
